---
name: "自动部署"
description: "一键部署Python Web应用到Linux服务器，支持SSL免费证书自动申请。Invoke when user wants to deploy or update a Python web application to a remote server."
---

# 自动部署技能

本技能用于一键部署 Python Web 应用到 Linux 服务器，支持 Let's Encrypt 免费 SSL 证书自动申请。

## 功能说明

- SSH 远程连接服务器
- 自动打包上传项目文件
- 安装 Python 依赖
- 配置 Nginx 反向代理
- 配置 systemd 服务（开机自启）
- 自动申请 Let's Encrypt 免费 SSL 证书
- 部署结果验证

## 使用前准备

### 1. 配置服务器信息

编辑 `deploy_config.py`，填入用户的服务器信息：

```python
SERVER_HOST = "服务器IP地址"        # 如 "192.168.1.100"
SERVER_USER = "root"               # SSH 用户名
PROJECT_NAME = "项目名称"          # 项目名称
DOMAIN = "域名"                    # 如 "example.com"
ENABLE_SSL = True                  # 是否启用 HTTPS
SSL_EMAIL = "用户邮箱"             # Let's Encrypt 证书邮箱
```

### 2. 密码配置

创建 `_pw.txt` 文件，写入服务器密码（此文件不会被提交到版本控制）。

## 执行命令

### 完整部署（首次部署）

```bash
python deploy.py
```

### 可选参数

| 参数 | 说明 |
|------|------|
| `--skip-ssl` | 跳过 SSL 安装 |
| `--ssl-only` | 只安装 SSL 证书 |
| `--upload-only` | 只上传文件（不重启服务） |
| `--restart` | 只重启服务 |

### 快速更新

代码修改后使用 `update.py` 快速更新：

```bash
python update.py          # 上传代码 + 重启服务
python update.py --upload # 只上传代码
python update.py --restart # 只重启服务
```

## 服务器要求

- 操作系统：Ubuntu 18.04+ / CentOS 7+
- Python 3.6+
- 域名已解析到服务器 IP
- 开放 80、443 端口

## 配置项说明

| 配置项 | 说明 | 默认值 |
|--------|------|--------|
| `SERVER_HOST` | 服务器 IP | 必填 |
| `SERVER_USER` | SSH 用户名 | `root` |
| `PROJECT_NAME` | 项目名称 | `myproject` |
| `DOMAIN` | 域名 | 必填 |
| `REMOTE_BASE_DIR` | 服务器项目目录 | `/opt/{PROJECT_NAME}` |
| `UPLOAD_DIRS` | 上传目录映射 | `{"backend": "backend"}` |
| `PYTHON_APP` | Python 入口 | `app.main:app` |
| `GUNICORN_PORT` | 应用端口 | `8000` |
| `GUNICORN_WORKERS` | Worker 数量 | `2` |
| `ENABLE_SSL` | 是否启用 SSL | `True` |
| `SSL_EMAIL` | SSL 证书邮箱 | 必填（启用SSL时） |

## 注意事项

1. 首次部署前确保域名已正确解析到服务器 IP
2. SSL 证书申请需要 80 端口可从外网访问
3. 密码文件 `_pw.txt` 不要提交到版本控制
4. 生产环境建议使用 SSH 密钥认证

## 故障排查

### SSH 连接失败
- 检查服务器 IP、用户名、密码
- 确认 SSH 端口（默认 22）已开放

### SSL 证书申请失败
- 确认域名解析正确
- 确认 80 端口可访问
- 检查 Nginx 是否正常运行

### 服务启动失败
```bash
systemctl status {PROJECT_NAME}
journalctl -u {PROJECT_NAME} -f
```
