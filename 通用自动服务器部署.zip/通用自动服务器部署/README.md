# 通用自动服务器部署工具

一键部署 Python Web 应用到 Linux 服务器，支持 SSL 免费证书自动申请。

## 功能特性

- SSH 远程连接服务器
- 自动打包上传项目文件
- 安装 Python 依赖
- 配置 Nginx 反向代理
- 配置 systemd 服务（开机自启）
- 自动申请 Let's Encrypt 免费 SSL 证书
- 部署结果验证

## 快速开始

### 1. 安装依赖

```bash
pip install paramiko
```

### 2. 配置服务器信息

编辑 `deploy_config.py`，填入您的服务器信息：

```python
# 服务器信息
SERVER_HOST = "您的服务器IP"        # 如 "192.168.1.100"
SERVER_USER = "root"               # SSH 用户名
SERVER_PASS = ""                   # 密码（推荐使用 _pw.txt 文件）

# 项目信息
PROJECT_NAME = "myproject"         # 项目名称
DOMAIN = "your-domain.com"         # 域名

# SSL 配置
ENABLE_SSL = True                  # 是否启用 HTTPS
SSL_EMAIL = "your@email.com"       # Let's Encrypt 邮箱
```

### 3. 密码配置（推荐）

创建 `_pw.txt` 文件，写入服务器密码：

```
your_password_here
```

> 注意：`_pw.txt` 已在 `.gitignore` 中，不会被提交到版本控制。

### 4. 执行部署

```bash
# 完整部署（首次）
python deploy.py

# 跳过 SSL 安装
python deploy.py --skip-ssl

# 只安装 SSL 证书
python deploy.py --ssl-only

# 只上传文件
python deploy.py --upload-only

# 只重启服务
python deploy.py --restart
```

### 5. 快速更新

代码修改后，使用 `update.py` 快速更新：

```bash
# 上传代码 + 重启服务
python update.py

# 只上传代码
python update.py --upload

# 只重启服务
python update.py --restart
```

## 目录结构

```
通用自动服务器部署/
├── deploy_config.py   # 配置文件（修改这里）
├── deploy.py          # 主部署脚本
├── update.py          # 快速更新脚本
├── _pw.txt            # 密码文件（需自行创建）
└── README.md          # 使用说明
```

## 配置说明

### deploy_config.py 主要配置项

| 配置项 | 说明 | 示例 |
|--------|------|------|
| `SERVER_HOST` | 服务器 IP 地址 | `"192.168.1.100"` |
| `SERVER_USER` | SSH 用户名 | `"root"` |
| `PROJECT_NAME` | 项目名称 | `"myapp"` |
| `DOMAIN` | 域名 | `"example.com"` |
| `REMOTE_BASE_DIR` | 服务器项目目录 | `"/opt/myapp"` |
| `UPLOAD_DIRS` | 上传目录映射 | `{"backend": "backend"}` |
| `PYTHON_APP` | Python 入口 | `"app.main:app"` |
| `GUNICORN_PORT` | 应用端口 | `8000` |
| `ENABLE_SSL` | 是否启用 SSL | `True` |
| `SSL_EMAIL` | SSL 证书邮箱 | `"admin@example.com"` |

### 上传目录配置

`UPLOAD_DIRS` 定义要上传的本地目录：

```python
UPLOAD_DIRS = {
    "backend": "backend",           # 本地 backend -> 服务器 backend
    "frontend/dist": "static",      # 本地 dist -> 服务器 static
}
```

## 服务器要求

- 操作系统：Ubuntu 18.04+ / CentOS 7+
- Python 3.6+
- 已配置域名解析到服务器 IP
- 开放 80、443 端口（SSL 证书申请需要）

## 常见问题

### 1. SSH 连接失败

- 检查服务器 IP、用户名、密码是否正确
- 确认服务器 SSH 端口（默认 22）已开放
- 如使用密钥认证，设置 `SERVER_KEY_PATH`

### 2. SSL 证书申请失败

- 确认域名已正确解析到服务器 IP
- 确认 80 端口可从外网访问
- 检查 Nginx 是否正常运行

### 3. 服务启动失败

```bash
# 查看服务状态
systemctl status myproject

# 查看日志
journalctl -u myproject -f
```

## 安全建议

1. 使用 `_pw.txt` 存储密码，避免提交到版本控制
2. 生产环境建议使用 SSH 密钥认证
3. 定期更新服务器系统和依赖包
4. 配置防火墙规则，只开放必要端口
