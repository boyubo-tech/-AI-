# -*- coding: utf-8 -*-
"""
============================================================
  自动部署配置文件（请填入您自己的服务器信息）
============================================================
  使用前请修改以下配置项：
  1. 服务器信息：SERVER_HOST, SERVER_USER, SERVER_PASS
  2. 项目信息：PROJECT_NAME, DOMAIN
  3. 目录结构：UPLOAD_DIRS, REMOTE_BASE_DIR
  4. SSL 配置：ENABLE_SSL, SSL_EMAIL（如需 HTTPS）
============================================================
"""

from __future__ import annotations

import os
from pathlib import Path


def _read_pw_from_file() -> str:
    """
    从外部文件读取密码（推荐方式）
    将密码存储在单独的文件中，避免提交到版本控制
    """
    pw_file = Path(__file__).resolve().parent / "_pw.txt"
    if pw_file.exists():
        return pw_file.read_text(encoding="utf-8", errors="replace").strip()
    return os.environ.get("DEPLOY_PW", "").strip()


# ==================== 服务器信息 ====================
# 请替换为您自己的服务器信息
SERVER_HOST = "YOUR_SERVER_IP"           # 服务器 IP 地址，如 "192.168.1.100"
SERVER_USER = "root"                      # SSH 用户名
SERVER_PASS = _read_pw_from_file()        # 密码（从 _pw.txt 文件读取，或留空使用密钥）
SERVER_KEY_PATH = ""                      # SSH 私钥路径（如使用密钥认证）

# ==================== 项目信息 ====================
PROJECT_NAME = "myproject"                # 项目名称（也是 systemd 服务名）
DOMAIN = "your-domain.com"                # 域名（如 example.com）
ADMIN_TOKEN = "your-admin-token"          # 管理员令牌（可选）

# ==================== 目录结构 ====================
REMOTE_BASE_DIR = f"/opt/{PROJECT_NAME}"  # 服务器上的项目根目录

# 要上传的本地目录映射
# 格式：{ "本地目录名": "远程目录名" }
# 例如：{ "backend": "backend", "frontend/dist": "static" }
UPLOAD_DIRS = {
    "backend": "backend",
}

# 需要在服务器上额外创建的目录
EXTRA_DIRS = ["logs", "data"]

# ==================== 服务配置 ====================
# Python 应用入口（gunicorn 格式）
PYTHON_APP = "app.main:app"               # 如 "main:app" 或 "server.app:app"
GUNICORN_WORKERS = 2                      # gunicorn worker 数量
GUNICORN_PORT = 8000                      # 应用监听端口
GUNICORN_TIMEOUT = 60                     # 请求超时时间（秒）

# ==================== Python 依赖 ====================
# 需要安装的 Python 包
PIP_PACKAGES = [
    "fastapi",
    "uvicorn[standard]",
    "gunicorn",
]

# ==================== Nginx 配置 ====================
# 额外的 Nginx location 配置（可选）
# 使用 {port} 占位符会被替换为 GUNICORN_PORT
NGINX_EXTRA_LOCATIONS = ""

# ==================== SSL 证书配置 ====================
ENABLE_SSL = True                         # 是否启用 SSL（Let's Encrypt 免费证书）
SSL_EMAIL = "your-email@example.com"      # Let's Encrypt 证书提醒邮箱

# ==================== systemd 服务环境变量 ====================
SERVICE_ENV_VARS = {
    "PYTHONUNBUFFERED": "1",
}

# ==================== 额外上传文件（可选）====================
# 格式：[("本地路径", "远程路径"), ...]
UPLOAD_FILES = [
    # ("dist/MyApp.exe", f"{REMOTE_BASE_DIR}/dist/MyApp.exe"),
]
