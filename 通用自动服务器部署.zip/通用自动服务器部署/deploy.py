# -*- coding: utf-8 -*-
"""
============================================================
  一键自动部署脚本（通用版）
============================================================
  功能：
  1. SSH 连接服务器
  2. 打包 & 上传项目文件
  3. 安装 Python 依赖
  4. 配置 Nginx 反向代理
  5. 配置 systemd 服务（开机自启）
  6. 安装 SSL 证书（HTTPS，Let's Encrypt 免费）
  7. 验证部署结果
============================================================
  使用方法：
  1. 修改 deploy_config.py 中的配置
  2. 运行: python deploy.py
  3. 可选参数:
     python deploy.py --skip-ssl    跳过 SSL 安装
     python deploy.py --ssl-only    只安装 SSL
     python deploy.py --upload-only 只上传文件（不重启服务）
     python deploy.py --restart     只重启服务
============================================================
"""

import sys
import os
import time
import zipfile
import argparse

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.stderr.reconfigure(encoding="utf-8", errors="replace")

try:
    import paramiko
except ImportError:
    print("[!] paramiko not installed. Installing...")
    os.system(f"{sys.executable} -m pip install paramiko")
    import paramiko

from deploy_config import *


class DeployLogger:
    """带计时的日志"""

    def __init__(self):
        self.start_time = time.time()
        self.step = 0

    def info(self, msg):
        elapsed = time.time() - self.start_time
        print(f"[{elapsed:6.1f}s] {msg}")

    def step_start(self, desc):
        self.step += 1
        self.info("")
        self.info(f"{'='*50}")
        self.info(f"  Step {self.step}: {desc}")
        self.info(f"{'='*50}")

    def success(self, msg):
        self.info(f"  [OK] {msg}")

    def warn(self, msg):
        self.info(f"  [WARN] {msg}")

    def error(self, msg):
        self.info(f"  [ERROR] {msg}")

    def cmd_output(self, text, max_lines=15):
        lines = text.strip().split("\n")
        for line in lines[-max_lines:]:
            if line.strip():
                print(f"         {line}")


log = DeployLogger()


class RemoteServer:
    """SSH 远程服务器操作封装"""

    def __init__(self, host, user, password=None, key_path=None):
        self.ssh = paramiko.SSHClient()
        self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        if key_path and os.path.exists(key_path):
            self.ssh.connect(host, username=user, key_filename=key_path, timeout=15)
        else:
            self.ssh.connect(host, username=user, password=password, timeout=15)

    def run(self, cmd, desc="", timeout=120):
        """执行远程命令"""
        if desc:
            log.info(f"  >> {desc}")
        log.info(f"     $ {cmd}")
        stdin, stdout, stderr = self.ssh.exec_command(cmd, timeout=timeout)
        out = stdout.read().decode("utf-8", errors="replace").strip()
        err = stderr.read().decode("utf-8", errors="replace").strip()
        code = stdout.channel.recv_exit_status()
        combined = (out + "\n" + err).strip()
        if combined:
            log.cmd_output(combined)
        return code, out, err

    def upload(self, local_path, remote_path):
        """上传文件"""
        sftp = self.ssh.open_sftp()
        sftp.put(local_path, remote_path)
        sftp.close()

    def close(self):
        self.ssh.close()


def create_zip(upload_dirs, zip_path):
    """把项目文件打包成 zip"""
    project_root = os.path.dirname(os.path.abspath(__file__))
    parent = os.path.dirname(project_root)

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for local_dir, remote_dir in upload_dirs.items():
            src = os.path.join(parent, local_dir)
            if not os.path.exists(src):
                src = os.path.join(project_root, "..", local_dir)
            if not os.path.exists(src):
                log.warn(f"Directory not found: {local_dir}, skipping")
                continue
            for root, dirs, files in os.walk(src):
                dirs[:] = [d for d in dirs if d != "__pycache__" and not d.startswith(".")]
                for f in files:
                    if f.endswith((".pyc", ".pyo")):
                        continue
                    filepath = os.path.join(root, f)
                    arcname = os.path.join(remote_dir, os.path.relpath(filepath, src))
                    zf.write(filepath, arcname)
    return zip_path


def generate_nginx_conf(domain, port, extra_locations=""):
    """生成 Nginx 配置"""
    extra = extra_locations.replace("{port}", str(port)) if extra_locations else ""
    return f"""server {{
    listen 80;
    server_name {domain};

    access_log /var/log/nginx/{domain}.access.log;
    error_log  /var/log/nginx/{domain}.error.log;
    client_max_body_size 200m;

    location / {{
        proxy_pass http://127.0.0.1:{port};
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 60s;
        proxy_connect_timeout 10s;
    }}
{extra}
}}"""


def generate_systemd_service(project_name, base_dir, app_entry, workers, port, timeout, env_vars):
    """生成 systemd 服务配置"""
    env_lines = "\n".join([f"Environment={k}={v}" for k, v in env_vars.items()])
    return f"""[Unit]
Description={project_name} service
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory={base_dir}/server
{env_lines}
ExecStart=/usr/bin/python3 -m gunicorn -w {workers} -b 127.0.0.1:{port} --timeout {timeout} {app_entry}
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target"""


def step_connect(server_host, server_user, server_pass, server_key):
    """Step: 连接服务器"""
    log.step_start("Connect to server")
    log.info(f"  Target: {server_user}@{server_host}")
    try:
        srv = RemoteServer(server_host, server_user, server_pass, server_key)
        log.success("Connected!")
        return srv
    except Exception as e:
        log.error(f"Connection failed: {e}")
        sys.exit(1)


def step_upload(srv, upload_dirs):
    """Step: 打包并上传文件"""
    log.step_start("Package & Upload files")

    zip_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_deploy_temp.zip")
    log.info("  Creating zip...")
    create_zip(upload_dirs, zip_path)

    size_kb = os.path.getsize(zip_path) // 1024
    log.info(f"  Zip size: {size_kb}KB")

    remote_zip = "/root/_deploy_temp.zip"
    log.info("  Uploading...")
    start = time.time()
    srv.upload(zip_path, remote_zip)
    elapsed = time.time() - start
    log.success(f"Upload done ({elapsed:.1f}s)")

    os.remove(zip_path)
    return remote_zip


def step_deploy_files(srv, remote_zip, base_dir, upload_dirs, extra_dirs):
    """Step: 解压并部署文件"""
    log.step_start("Deploy files to server")

    srv.run(
        "apt-get install -y unzip >/dev/null 2>&1 || yum install -y unzip >/dev/null 2>&1; echo ok",
        "Ensure unzip installed",
    )

    all_dirs = [f"{base_dir}/{d}" for d in upload_dirs.values()]
    all_dirs += [f"{base_dir}/{d}" for d in extra_dirs]
    srv.run(f"mkdir -p {' '.join(all_dirs)}", "Create directories")

    srv.run("rm -rf /root/_deploy_unzip && mkdir -p /root/_deploy_unzip", "Clean temp dir")
    srv.run(f"unzip -o {remote_zip} -d /root/_deploy_unzip", "Unzip files")

    for _, remote_dir in upload_dirs.items():
        srv.run(
            f"cp -r /root/_deploy_unzip/{remote_dir}/* {base_dir}/{remote_dir}/ 2>/dev/null || true",
            f"Copy {remote_dir}",
        )

    srv.run(f"rm -rf /root/_deploy_unzip {remote_zip}", "Cleanup")
    log.success("Files deployed!")


def step_install_deps(srv, packages):
    """Step: 安装 Python 依赖"""
    log.step_start("Install Python dependencies")

    pkg_str = " ".join(packages)

    code, out, err = srv.run(
        f"pip3 install --break-system-packages {pkg_str} 2>&1 | tail -5", "Install packages"
    )

    if "Cannot uninstall" in (out + err):
        log.warn("System package conflict, retrying with --ignore-installed")
        srv.run(
            f"pip3 install --break-system-packages --ignore-installed {pkg_str} 2>&1 | tail -5",
            "Retry install",
        )

    srv.run("python3 -c 'print(\"OK\")'", "Verify python")
    log.success("Dependencies step finished")


def step_setup_nginx(srv, domain, port, extra_locations):
    """Step: 配置 Nginx"""
    log.step_start("Setup Nginx")

    code, out, _ = srv.run("which nginx >/dev/null 2>&1 && echo 'FOUND' || echo 'NOT_FOUND'")
    if "NOT_FOUND" in out:
        srv.run(
            "apt-get install -y nginx >/dev/null 2>&1 || yum install -y nginx >/dev/null 2>&1",
            "Install Nginx",
        )

    conf = generate_nginx_conf(domain, port, extra_locations)
    conf_path = f"/etc/nginx/conf.d/{domain}.conf"

    escaped = conf.replace("'", "'\\''")
    srv.run(f"echo '{escaped}' > {conf_path}", "Write Nginx config")

    code, out, err = srv.run("nginx -t 2>&1", "Test config")
    if "successful" in out or "successful" in err:
        srv.run("systemctl reload nginx", "Reload Nginx")
        log.success("Nginx configured!")
    else:
        log.error("Nginx config test failed!")


def step_setup_service(srv, project_name, base_dir, app_entry, workers, port, timeout, env_vars):
    """Step: 配置 systemd 服务"""
    log.step_start("Setup systemd service")

    service_name = project_name
    conf = generate_systemd_service(project_name, base_dir, app_entry, workers, port, timeout, env_vars)
    service_path = f"/etc/systemd/system/{service_name}.service"

    escaped = conf.replace("'", "'\\''")
    srv.run(f"echo '{escaped}' > {service_path}", "Write service file")
    srv.run("systemctl daemon-reload", "Daemon reload")
    srv.run(f"systemctl enable {service_name}", "Enable service")
    srv.run(f"systemctl restart {service_name}", "Start service")

    log.info("  Waiting 4s for service to start...")
    time.sleep(4)
    srv.run(f"systemctl is-active {service_name}", "Check status")
    log.success("Service step finished")


def step_setup_ssl(srv, domain, email):
    """Step: 安装 SSL 证书（Let's Encrypt 免费）"""
    log.step_start("Setup SSL certificate (Let's Encrypt)")

    srv.run(
        "apt-get install -y certbot python3-certbot-nginx -qq 2>&1 | tail -3", "Install certbot"
    )

    code, out, err = srv.run(
        f"certbot --nginx -d {domain} --non-interactive --agree-tos --email {email} --redirect 2>&1",
        "Get SSL certificate",
        timeout=120,
    )

    if "Successfully" in out or "Congratulations" in out:
        log.success(f"SSL certificate installed for {domain}!")
    elif "already" in out.lower():
        log.success(f"SSL certificate already exists for {domain}")
    else:
        log.warn("SSL setup may have issues, check output above")

    srv.run("systemctl reload nginx", "Reload Nginx")


def step_upload_files(srv, upload_files):
    """Step: 上传额外大文件"""
    if not upload_files:
        return
    log.step_start("Upload extra files")
    for local_path, remote_path in upload_files:
        if not os.path.exists(local_path):
            log.warn(f"File not found: {local_path}, skipping")
            continue
        size_mb = os.path.getsize(local_path) / 1024 / 1024
        log.info(f"  Uploading {os.path.basename(local_path)} ({size_mb:.1f}MB)...")
        start = time.time()
        srv.upload(local_path, remote_path)
        elapsed = time.time() - start
        log.success(f"Uploaded ({elapsed:.1f}s)")


def step_verify(srv, domain, port):
    """Step: 验证部署"""
    log.step_start("Verify deployment")

    code, out, _ = srv.run(
        f"curl -s -o /dev/null -w '%{{http_code}}' http://127.0.0.1:{port}/", "Test local"
    )
    log.info(f"  Local HTTP: {out}")

    code, out, _ = srv.run(
        f"curl -s -o /dev/null -w '%{{http_code}}' http://{domain}/", "Test domain (HTTP)"
    )
    log.info(f"  Domain HTTP: {out}")

    code, out, _ = srv.run(
        f"curl -s -o /dev/null -w '%{{http_code}}' https://{domain}/ 2>/dev/null",
        "Test domain (HTTPS)",
    )
    log.info(f"  Domain HTTPS: {out}")
    return "200" in out


def main():
    parser = argparse.ArgumentParser(description="One-click deployment")
    parser.add_argument("--skip-ssl", action="store_true", help="Skip SSL setup")
    parser.add_argument("--ssl-only", action="store_true", help="Only setup SSL")
    parser.add_argument("--upload-only", action="store_true", help="Only upload files")
    parser.add_argument("--restart", action="store_true", help="Only restart service")
    args = parser.parse_args()

    log.info("=" * 55)
    log.info(f"  Auto Deploy: {PROJECT_NAME}")
    log.info(f"  Domain:      {DOMAIN}")
    log.info(f"  Server:      {SERVER_USER}@{SERVER_HOST}")
    log.info("=" * 55)

    srv = step_connect(SERVER_HOST, SERVER_USER, SERVER_PASS, SERVER_KEY_PATH)
    try:
        if args.ssl_only:
            step_setup_ssl(srv, DOMAIN, SSL_EMAIL)
            step_verify(srv, DOMAIN, GUNICORN_PORT)
        elif args.restart:
            srv.run(f"systemctl restart {PROJECT_NAME}", f"Restart {PROJECT_NAME}")
            time.sleep(2)
            srv.run(f"systemctl is-active {PROJECT_NAME}", "Check status")
        elif args.upload_only:
            remote_zip = step_upload(srv, UPLOAD_DIRS)
            step_deploy_files(srv, remote_zip, REMOTE_BASE_DIR, UPLOAD_DIRS, EXTRA_DIRS)
        else:
            remote_zip = step_upload(srv, UPLOAD_DIRS)
            step_deploy_files(srv, remote_zip, REMOTE_BASE_DIR, UPLOAD_DIRS, EXTRA_DIRS)
            step_install_deps(srv, PIP_PACKAGES)
            step_setup_nginx(srv, DOMAIN, GUNICORN_PORT, NGINX_EXTRA_LOCATIONS)
            step_setup_service(
                srv,
                PROJECT_NAME,
                REMOTE_BASE_DIR,
                PYTHON_APP,
                GUNICORN_WORKERS,
                GUNICORN_PORT,
                GUNICORN_TIMEOUT,
                SERVICE_ENV_VARS,
            )
            if ENABLE_SSL and not args.skip_ssl:
                step_setup_ssl(srv, DOMAIN, SSL_EMAIL)
            step_upload_files(srv, UPLOAD_FILES)
            ok = step_verify(srv, DOMAIN, GUNICORN_PORT)
            log.info("")
            log.info("=" * 55)
            log.info("  DEPLOY SUCCESS!" if ok else "  DEPLOY COMPLETE (some checks may need time)")
            log.info("=" * 55)
            log.info(f"  Website:   https://{DOMAIN}")
            log.info("=" * 55)
    finally:
        srv.close()
        log.info("Connection closed.")


if __name__ == "__main__":
    main()
