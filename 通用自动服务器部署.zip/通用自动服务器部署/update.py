# -*- coding: utf-8 -*-
"""
============================================================
  一键更新脚本
============================================================
  快速更新服务器上的代码（不上传大文件，不重装依赖）
  使用方法：
  python update.py          # 上传代码 + 重启服务
  python update.py --upload # 只上传代码
  python update.py --restart # 只重启服务
============================================================
"""

import sys
import subprocess
import time
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from deploy_config import PROJECT_NAME, DOMAIN, GUNICORN_PORT


def run_local(cmd, desc=""):
    """运行本地命令"""
    if desc:
        print(f"[>] {desc}")
    print(f"    $ {' '.join(cmd)}")
    result = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if result.stdout:
        for line in result.stdout.strip().split("\n")[-10:]:
            print(f"       {line}")
    if result.returncode != 0 and result.stderr:
        for line in result.stderr.strip().split("\n")[-5:]:
            print(f"       [ERR] {line}")
    return result.returncode == 0


def health_check(domain, max_wait=30):
    """健康检查"""
    print(f"[>] Health check: https://{domain}/")
    for i in range(max_wait):
        try:
            result = subprocess.run(
                ["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}", f"https://{domain}/"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            code = result.stdout.strip()
            if code == "200":
                print(f"    [OK] HTTP 200 - Service is healthy!")
                return True
            print(f"    [{i+1}/{max_wait}] HTTP {code}, waiting...")
        except Exception as e:
            print(f"    [{i+1}/{max_wait}] Error: {e}")
        time.sleep(1)
    print("    [WARN] Health check timeout, but service may still be starting...")
    return False


def main():
    import argparse

    parser = argparse.ArgumentParser(description="Quick update script")
    parser.add_argument("--upload", action="store_true", help="Only upload files")
    parser.add_argument("--restart", action="store_true", help="Only restart service")
    args = parser.parse_args()

    script_dir = Path(__file__).resolve().parent
    deploy_py = script_dir / "deploy.py"

    print("=" * 50)
    print(f"  Quick Update: {PROJECT_NAME}")
    print("=" * 50)

    if args.upload:
        run_local([sys.executable, str(deploy_py), "--upload-only"], "Upload files only")
    elif args.restart:
        run_local([sys.executable, str(deploy_py), "--restart"], "Restart service only")
        health_check(DOMAIN)
    else:
        run_local([sys.executable, str(deploy_py), "--upload-only"], "Upload files")
        run_local([sys.executable, str(deploy_py), "--restart"], "Restart service")
        health_check(DOMAIN)

    print("")
    print("=" * 50)
    print("  UPDATE COMPLETE!")
    print(f"  Website: https://{DOMAIN}")
    print("=" * 50)


if __name__ == "__main__":
    main()
